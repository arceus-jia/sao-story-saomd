# character_color

Original strings from this table, listed once per distinct value.

## 1

126011\_2

## 2

Black

## 3

4\_sinon\_124001\_2

## 4

126009\_2

## 5

126006\_2

## 6

126005\_2

## 7

66049\_2

## 8

Cape Outfit

## 9

6\_asuna\_66049\_02

## 10

66040\_2

## 11

Purple

## 12

5\_asuna\_65002\_2

## 13

66018\_2

## 14

66002\_2

## 15

66001\_2

## 16

4\_asuna\_64001\_2

## 17

65001\_2

## 18

46018\_2

## 19

Priestess Costume

## 20

6\_yui\_46018\_2

## 21

36001\_2

## 22

White

## 23

4\_kirito\_34001\_2

## 24

35001\_2

## 25

34001\_2

## 26

Original Outfit 2P color

## 27

26053\_2

## 28

4\_yuuki\_24002\_2

## 29

26051\_2

## 30

26027\_2

## 31

26003\_2

## 32

11001\_3

## 33

Test Outfit 11001\_2

## 34

11001\_2

## 35

Test Outfit 11001\_1

## 36

1\_kirito\_11001\_2
